<?php
	/* 
		 ____  __  __  ___  ____  ____  ___  _   _ 
		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
				|___/\___/|___| |_| |___|_| |___|___/_||_|
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Versioning File to Contain Module Information!
	*/ if(!is_array(@$object)) { @http_response_code(404); Header("Location: ../"); exit(); }
	
	########################################################################################################################
	// Initialize X Array
	########################################################################################################################
		$x = array();

	########################################################################################################################
	// Module Details
	########################################################################################################################
		// Unique Module ID
		// - This is a unique id for your module
		// - If you want your module in the public store contact the developers to get your unique module id.
		// - Request unique module id for official publication at requestid@suitefish.com
		// - If you do not have a registered unique module id start your rname with "xxx"
		// - Use maximum of 15 signs
		// - No special chars, only a-Z
		// - No numeric chars
		// - Underscore (_) prefix is dedicated to suitefish official releases
		// - This variable is mandatory
		$x["rname"] 		= "_swimgdl";
		// Available Languages 
		// - Short Codes of available languages in PHP Array
		// - This variable is mandatory
		$x["lang"] 			= array("en");
		// Build Number:
		// - Do only use integer values here
		// - Will extend the version number
		// - Do not use special chars, not even dots
		// - This variable is mandatory
		$x["build"] 		= "0";
		// Module Version
		// - Always add the build number at the end, seperated by a dot (.)
		// - Define the main Version number if the module.
		// - This variable is mandatory
		$x["version"] 		= "1.".$x["build"];
		// Module Name 
		// - Define the Title of the Module displayed in different frontpage areas.
		// - Only text, no html codes
		// - This variable is mandatory
		$x["name"] 			= "Image Downloader";
		// Module Description 
		// - Define the Description of the Module displayed in different frontpage areas.
		// - Only text and simple html codes (like br, li, table)
		// - Do not use style, script or other kind of complex tags
		// - This variable is mandatory
		$x["description"] = "Welcome to Bugfish Image Downloader, a versatile software tool designed for downloading images from websites. This utility enables you to input a URL, upon which it will retrieve and save all images found on the specified website. The downloaded images are organized into folders within the application's directory.";
		// Module Type
		// - There are different Types of Modules inside Suitefish CMS
		// - The set ID 4 is dedicated to software modules and will than be recognized as one.
		// - Other possible values: 1 - Site | 2 - Extension | 3 - Image | 4 - Windows | 5 - Docker | 6 - Theme
		// - This variable is mandatory
		$x["type"] 			= 4;
	
	########################################################################################################################
	// Module Author
	########################################################################################################################
		// Module License (gplv3, gplv2, mit, bsd, bsd2, ...) (can be false)
		$x["license"] 		= "gplv3";
		// Module Author Name (can be false)
		$x["author"] 		= "Bugfish";
		// Module Author Mail (can be false)
		$x["mail"] 			= false;
		// Module Author Website (can be false)
		$x["website"] 		= false;
		// Module Documentation Website (can be false)
		$x["documentation"] = "https://bugfishtm.github.io/bugfish-image-downloader/";
		// Module Github Website (can be false)
		$x["github"] 		= "https://github.com/bugfishtm/bugfish-image-downloader";	
		// Module Video URL (a video about the module if exists, can be false)
		$x["video"] 		= false;	

	########################################################################################################################
	// Dedicated Module Type Variables
	########################################################################################################################	
		// Starter File for Windows Software
		// - File should be .exe/.bat or similar
		// - File will be the starter file of the software package
		// - Do not use leading / or ./
		// - Relative to software module package path
		// - This variable is mandatory
		$x["software_executable"] 		= "image-downloader.exe";