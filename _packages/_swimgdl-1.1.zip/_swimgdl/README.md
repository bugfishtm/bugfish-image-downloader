# 📦 Image Downloader

## 📙 Information

Welcome to Bugfish Image Downloader, a versatile software tool designed for downloading images from websites. This utility enables you to input a URL, upon which it will retrieve and save all images found on the specified website. The downloaded images are organized into folders within the application's directory.

- Easily download images from websites of your choice.
- Configure settings to search for images within subsites of the specified website.
- Choose to download only high-definition images with a width of at least 1000 pixels.
- Note: While Bugfish Image Downloader is compatible with many websites, it may not work on all. Feel free to give it a try for your image downloading needs.


To run Bugfish Image Downloader, you need a Windows operating system with .NET Framework 4.5 installed. The software is designed to run without the need for installation, and it does not write or utilize any registry keys. All folders and files are created in the same location as the executable file.

This is a software module to deploy software to suitefish-windows client instances via a suitefish-cms store. You need the windows software on your computer to use this software package or a valid suitefish online instance to deploy it for software clients.

## 📄 Documentation

If you are a developer you can find examples of modules in the _developers folder at the suitefish-cms github repository if you want to create an own module!

You can find the image downloader at: https://github.com/bugfishtm/bugfish-image-downloader  
You can find the suitefish windows software at: https://github.com/bugfishtm/suitefish-windows  
For more information about the Suitefish CMS: https://github.com/bugfishtm/suitefish-cms

## 🛠️ Installation

You have three ways installing this software module.

### Software Store

Open the suitefish windows software and browse our software store to find the module you need, than simply download and install it using the interface.

### Manual Installation

Open the suitefish windows software and browse to the area to insert software modules, select this modules zip file and wait for the suitefish software to extract and install it, it will than show up in the interface.

### Manual Alternative

You can also just unzip the modules zip file and execute the starter .exe file which is defined in version.php. The disadvantage will be that no auto-update of this software will be possible as it is not connected with the suitefish windows software.

🐟 Bugfish